#include "types.h"
#include "stat.h"
#include "user.h"

#define LOOPS 400000000

static void
spin(void)
{
  volatile int x = 0;
  int i;
  for(i = 0; i < LOOPS; i++)
    x += i;
}

int
main(void)
{
  int prios[3] = {5, 10, 15};
  int i, pid;

  set_priority(getpid(), 1);
  for(i = 0; i < 3; i++){
    pid = fork();
    if(pid < 0){
      printf(1, "fork failed\n");
      exit();
    }
    if(pid == 0){
      spin();
      printf(1, "priority %d finished\n", prios[i]);
      exit();
    }
    set_priority(pid, prios[i]);
  }
  for(i = 0; i < 3; i++)
    wait();
  printf(1, "Done\n");
  exit();
}
