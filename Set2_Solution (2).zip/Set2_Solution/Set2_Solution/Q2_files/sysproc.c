#include "types.h"
#include "x86.h"
#include "defs.h"
#include "date.h"
#include "param.h"
#include "memlayout.h"
#include "mmu.h"
#include "proc.h"

int
sys_fork(void)
{
  return fork();
}

int
sys_exit(void)
{
  exit();
  return 0;  // not reached
}

int
sys_wait(void)
{
  return wait();
}

int
sys_kill(void)
{
  int pid;

  if(argint(0, &pid) < 0)
    return -1;
  return kill(pid);
}

int
sys_getpid(void)
{
  return myproc()->pid;
}

int
sys_sbrk(void)
{
  int addr;
  int n;

  if(argint(0, &n) < 0)
    return -1;
  addr = myproc()->sz;
  if(growproc(n) < 0)
    return -1;
  return addr;
}

int
sys_sleep(void)
{
  int n;
  uint ticks0;

  if(argint(0, &n) < 0)
    return -1;
  acquire(&tickslock);
  ticks0 = ticks;
  while(ticks - ticks0 < n){
    if(myproc()->killed){
      release(&tickslock);
      return -1;
    }
    sleep(&ticks, &tickslock);
  }
  release(&tickslock);
  return 0;
}

// return how many clock tick interrupts have occurred
// since start.
int
sys_uptime(void)
{
  uint xticks;

  acquire(&tickslock);
  xticks = ticks;
  release(&tickslock);
  return xticks;
}

int
sys_mprotect(void)
{
  int addr, len;
  if(argint(0, &addr) < 0 || argint(1, &len) < 0)
    return -1;
  return change_prot((void*)addr, len, 0);
}

int
sys_munprotect(void)
{
  int addr, len;
  if(argint(0, &addr) < 0 || argint(1, &len) < 0)
    return -1;
  return change_prot((void*)addr, len, 1);
}

int
sys_set_priority(void)
{
  int pid, priority;
  if(argint(0, &pid) < 0 || argint(1, &priority) < 0)
    return -1;
  return set_priority(pid, priority);
}
# Running both questions for roll number 2403mc05

Use Ubuntu or Debian, or WSL on Windows. I could not boot it myself, so the expected outputs below are what the code should print.

## 1. Install tools (once)

```bash
sudo apt update
sudo apt install -y build-essential gcc-multilib qemu-system-x86 unzip
```

## 2. Unzip and enter the source

```bash
cd ~/Downloads
unzip Set2_Solution.zip
cd Set2_Solution/xv6
```

## 3. Fix the build error on new GCC

Skip this if the build in step 4 works without it.

```bash
sed -i 's/-Werror//' Makefile
```

## 4. Question 1: run and capture the log

```bash
make clean
make qemu-nox CPUS=1 | tee ../Q1_output.txt
```

At the xv6 `$` prompt, type:

```
echo 2403mc05
prottest
```

Expected output:

```
2403mc05
(i) after mprotect, read: A
pid 4 prottest: trap 14 err 7 on cpu 0 eip 0x... addr 0x... --kill proc
(ii) parent still sees: A
(iii) after munprotect, wrote: C
(iv) unaligned addr: -1
(iv) len = 0:        -1
(iv) len < 0:        -1
(iv) beyond sz:      -1
(iv) munprotect bad: -1
prottest done
```

The `trap 14 ... --kill proc` line is the kernel killing the child. The pid number may differ.

Leave QEMU by pressing **Ctrl-a**, releasing it, then pressing **x**.

## 5. Question 2: run and capture the log

```bash
make qemu-nox CPUS=1 | tee ../Q2_output.txt
```

At the `$` prompt:

```
echo 2403mc05
schedtest
```

Expected output, in this order:

```
2403mc05
priority 5 finished
priority 10 finished
priority 15 finished
Done
```

Leave QEMU with **Ctrl-a**, then **x**.

If it finishes too fast or too slowly, change `LOOPS` in `schedtest.c`, then run `make qemu-nox CPUS=1` again. The order must stay 5, 10, 15.

## 6. Prepare the submission

```bash
cd ~/Downloads/Set2_Solution
nano README.txt          # fill in your name and roll number 2403mc05, then save with Ctrl-o, Enter, Ctrl-x
cd xv6 && make clean && cd ..

mkdir ~/Downloads/2403mc05_name
tar czf 2403mc05_name/2403mc05_Set2.tar.gz xv6/
cp Q1_output.txt Q2_output.txt README.txt 2403mc05_name/
ls 2403mc05_name
```

Replace `name` in the folder name with your actual name. Zip and submit the folder `2403mc05_name`:

```bash
cd ~/Downloads && zip -r 2403mc05_name.zip 2403mc05_name
```

The exam asks for the console logs to be named `Q1_output` and `Q2_output`. If a screenshot is accepted instead, take one at the end of steps 4 and 5, with `2403mc05` visible on screen.


That error means `make` can't find a `Makefile` in the folder you're in. You're almost certainly in the wrong directory. Run these to check:

```bash
pwd
ls
```

You should see `Makefile`, `proc.c`, `vm.c`, `prottest.c` and similar files. If you don't, find the right folder:

```bash
cd ~/Downloads
find . -name Makefile -path "*xv6*"
```

This prints something like `./Set2_Solution/xv6/Makefile`. Go into that folder (use the path it printed):

```bash
cd ~/Downloads/Set2_Solution/xv6
ls Makefile
```

Once `ls Makefile` shows the file, continue:

```bash
make clean
make qemu-nox CPUS=1 | tee ../Q1_output.txt
```

**Other causes**

- **The `find` prints nothing:** the unzip didn't happen, or the zip is somewhere else. Run `ls ~/Downloads | grep -i set2`, then `cd ~/Downloads && unzip Set2_Solution.zip`.
- **The folder is nested one level deeper**, like `Set2_Solution/Set2_Solution/xv6`: use the exact path that `find` shows.
- **You are in WSL and the zip is on the Windows side:** your Downloads is at `/mnt/c/Users/<YourWindowsName>/Downloads`, not `~/Downloads`. Use `cd /mnt/c/Users/<YourWindowsName>/Downloads` first.

If it still fails, paste the output of `pwd` and `ls` and I'll tell you the exact fix.





///
That error means `make` found a Makefile, but not the xv6 one. Most likely you are in a folder that has a different Makefile. Check with these commands:

```bash
pwd
ls
grep -c "qemu-nox" Makefile
```

If the last command prints `0`, or `ls` doesn't show `proc.c`, `vm.c` and `prottest.c`, you are in the wrong folder. This is the quickest way to get back on track: unzip into a fresh folder and go straight to the right place.

```bash
cd ~
rm -rf s2
mkdir s2
cd s2
unzip ~/Downloads/Set2_Solution.zip
cd Set2_Solution/xv6
pwd
ls
grep -c "qemu-nox" Makefile
```

You should now see `proc.c`, `vm.c` and `prottest.c`, and the last command should print a number of 1 or more. Then run:

```bash
make clean
make qemu-nox CPUS=1 | tee ../Q1_output.txt
```

If `make` then gives a different error, such as `-Werror` or `mp.c`, run this and try again:

```bash
sed -i 's/-Werror//' Makefile
make clean
make qemu-nox CPUS=1 | tee ../Q1_output.txt
```

If it still says no rule, paste the full output of `pwd`, `ls` and `head -20 Makefile` here, and I'll tell you what's wrong.


Your folder is correct now. The build is stopping on a compiler warning (`infinite-recursion` in `sh.c`) that newer GCC treats as an error because of `-Werror`. This is stock xv6 code, not part of my changes. Remove `-Werror` (the step I mentioned earlier) and rebuild:

```bash
sed -i 's/-Werror//' Makefile
grep -c Werror Makefile
make clean
make qemu-nox CPUS=1 | tee ../Q1_output.txt
```

The `grep -c` line should print `0`. If it prints more than that, the flag is still in the Makefile, so tell me what it shows.

After the build you'll see QEMU boot and the `$` prompt. Type:

```
echo 2403mc05
prottest
```

Leave QEMU with **Ctrl-a**, release, then **x**.

For Question 2, run this from the same folder:

```bash
make qemu-nox CPUS=1 | tee ../Q2_output.txt
```

At the prompt:

```
echo 2403mc05
schedtest
```

Then **Ctrl-a**, then **x** to exit.

///
The cause is a typo in the `sed` command. The screenshot shows `s/Werror//` without the leading dash, which left a stray `-` in the Makefile (`gcc - -Wall`). Restore the Makefile from the zip's copy and apply the correct command, which includes the dash:

```bash
cp ../Q1_files/Makefile Makefile
sed -i 's/-Werror//' Makefile
grep -n "Werror\|gcc - " Makefile
```

The `grep` should print nothing. Then rebuild:

```bash
make clean
make qemu-nox CPUS=1 | tee ../Q1_output.txt
```

At the `$` prompt type `echo 2403mc05` and then `prottest`. Leave QEMU with **Ctrl-a**, then **x**.

If the `grep` prints any lines, paste them here.