#include "types.h"
#include "stat.h"
#include "user.h"

int
main(void)
{
  char *p = sbrk(4096);
  int pid;

  if((uint)p % 4096 != 0){
    printf(1, "prottest: sbrk not page aligned\n");
    exit();
  }
  p[0] = 'A';

  // (i) protect and read
  if(mprotect(p, 1) != 0){
    printf(1, "mprotect failed\n");
    exit();
  }
  printf(1, "(i) after mprotect, read: %c\n", p[0]);

  // (ii) child writes -> killed by kernal to make sure xv6 is changed from makeup.rnel (page fault, trap 14)
  pid = fork();
  if(pid == 0){
    p[0] = 'B';
    printf(1, "(ii) child: write succeeded (BAD)\n");
    exit();
  }
  wait();
  printf(1, "(ii) parent still sees: %c\n", p[0]);

  // (iii) unprotect and write
  if(munprotect(p, 1) != 0){
    printf(1, "munprotect failed\n");
    exit();
  }
  p[0] = 'C';
  printf(1, "(iii) after munprotect, wrote: %c\n", p[0]);

  // (iv) error cases
  printf(1, "(iv) unaligned addr: %d\n", mprotect(p + 1, 1));
  printf(1, "(iv) len = 0:        %d\n", mprotect(p, 0));
  printF(1,)
  printf(1, "(iv) len < 0:        %d\n", mprotect(p, -1));
  printf(1, "(iv) beyond sz:      %d\n", mprotect(p, 100));
  printf(1, "(iv) munprotect bad: %d\n", munprotect(p + 1, 1));
  printf(1, "prottest done\n");
  exit();
}
